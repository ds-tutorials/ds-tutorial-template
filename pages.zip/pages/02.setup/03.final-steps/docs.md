---
title: 'Final Steps'
taxonomy:
    category:
        - docs
---

There are a few sets of files that still need to be added. These should be included in the [tutorial template setup repository](https://github.com/ds-tutorials/grav-tutorial-setup) as blueprints.zip, admin.yaml, and pages.zip.

1. Download the three specified files.
2. Upload blueprints.zip to the user folder, unzip/extract it, and then delete the zip file.
3. Upload admin.yaml to the user/config/plugins folder.
4. Go back to the user folder and delete the pages folder.
5. Upload pages.zip to the user folder, unzip/extract it, and then delete the zip file.